def mytest():
    print('just to test the package')